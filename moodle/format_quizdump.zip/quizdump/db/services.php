<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Web service definitions for format_quizdump.
 *
 * @package   format_quizdump
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'format_quizdump_get_quizzes' => [
        'classname' => 'format_quizdump\\external\\get_quizzes',
        'methodname' => 'execute',
        'description' => 'List the visible quizzes of a course.',
        'type' => 'read',
        'ajax' => false,
        'capabilities' => 'format/quizdump:view',
    ],
    'format_quizdump_get_quiz_questions' => [
        'classname' => 'format_quizdump\\external\\get_quiz_questions',
        'methodname' => 'execute',
        'description' => 'Get the questions, answer options and correct answers of a visible quiz.',
        'type' => 'read',
        'ajax' => false,
        'capabilities' => 'format/quizdump:view,mod/quiz:view',
    ],
];
