<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace format_quizdump\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Reads quiz structure, questions and answers from the Moodle database.
 *
 * Moodle core web services do not expose the content of quiz questions nor
 * their correct answers, so this class queries the question bank tables
 * directly (Moodle 4.0+ question_references / question_versions model).
 *
 * @package   format_quizdump
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class quiz_service {

    /** @var string[] Question types whose answers can be extracted reliably. */
    const SUPPORTED_TYPES = ['multichoice', 'truefalse', 'shortanswer', 'match', 'numerical', 'essay'];

    /**
     * Returns the quizzes of a course that are visible to the given user.
     *
     * @param int $courseid Course id.
     * @param int $userid User id (normally the token owner).
     * @return array
     */
    public static function get_visible_quizzes(int $courseid, int $userid): array {
        global $DB;

        $course = get_course($courseid);
        $context = \context_course::instance($course->id);
        require_capability('format/quizdump:view', $context);

        $modinfo = get_fast_modinfo($course, $userid);
        $instances = $modinfo->get_instances_of('quiz');
        if (empty($instances)) {
            return [];
        }

        $records = $DB->get_records_list('quiz', 'id', array_keys($instances), '',
            'id, course, name, intro, introformat, timeopen, timeclose, attempts');

        $quizzes = [];
        foreach ($instances as $instanceid => $cm) {
            if (!isset($records[$instanceid]) || $cm->deletioninprogress) {
                continue;
            }
            // Only course modules that are visible and available for this user.
            if (!$cm->visible || !$cm->uservisible) {
                continue;
            }
            $quizzes[] = self::format_quiz($records[$instanceid], $cm, $context);
        }

        usort($quizzes, function(array $a, array $b): int {
            return [$a['section'], $a['name']] <=> [$b['section'], $b['name']];
        });

        return $quizzes;
    }

    /**
     * Returns a quiz with all its questions, answer options and correct answers.
     *
     * @param int $quizid Quiz id (not cmid).
     * @param int $userid User id (normally the token owner).
     * @param bool $includehidden Allow dumping hidden quizzes (needs moodle/course:manageactivities).
     * @return array
     */
    public static function get_quiz_questions(int $quizid, int $userid, bool $includehidden = false): array {
        global $DB;

        $quiz = $DB->get_record('quiz', ['id' => $quizid], '*', MUST_EXIST);
        $course = get_course($quiz->course);
        $cm = get_coursemodule_from_instance('quiz', $quiz->id, $course->id, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);
        $coursecontext = \context_course::instance($course->id);

        require_capability('format/quizdump:view', $context);
        require_capability('mod/quiz:view', $context);

        $modinfo = get_fast_modinfo($course, $userid);
        $cminfo = $modinfo->get_cm($cm->id);

        if ($cminfo->deletioninprogress) {
            throw new \moodle_exception('errorquiznotvisible', 'format_quizdump');
        }
        if (!$cm->visible) {
            if (!$includehidden) {
                throw new \moodle_exception('errorquiznotvisible', 'format_quizdump');
            }
            require_capability('moodle/course:manageactivities', $coursecontext);
        } else if (!$cminfo->uservisible) {
            throw new \moodle_exception('errorquiznotavailable', 'format_quizdump');
        }

        $slots = $DB->get_records('quiz_slots', ['quizid' => $quiz->id], 'slot ASC');
        $refcolumns = $DB->get_columns('question_references');
        $hasversionfield = array_key_exists('version', $refcolumns);

        $questions = [];
        foreach ($slots as $slot) {
            $refs = $DB->get_records('question_references', [
                'component' => 'mod_quiz',
                'questionarea' => 'slot',
                'itemid' => $slot->id,
            ], 'id ASC', '*', 0, 1);
            $ref = reset($refs);
            if (!$ref) {
                continue;
            }

            $version = null;
            if ($hasversionfield && !empty($ref->version)) {
                $version = $DB->get_record('question_versions', [
                    'questionbankentryid' => $ref->questionbankentryid,
                    'version' => $ref->version,
                ], '*', IGNORE_MISSING);
            }
            if (!$version) {
                $versions = $DB->get_records('question_versions',
                    ['questionbankentryid' => $ref->questionbankentryid], 'version DESC', '*', 0, 1);
                $version = reset($versions) ?: null;
            }
            if (!$version) {
                continue;
            }

            $question = $DB->get_record('question', ['id' => $version->questionid], '*', IGNORE_MISSING);
            if (!$question) {
                continue;
            }

            $questions[] = self::format_question($slot, $question, $version);
        }

        return [
            'quiz' => self::format_quiz($quiz, $cminfo, $coursecontext),
            'questions' => $questions,
        ];
    }

    /**
     * Formats a quiz record for the web service response.
     *
     * @param \stdClass $quiz Quiz record.
     * @param \cm_info $cm Course module info.
     * @param \context $context Context used to format the name.
     * @return array
     */
    private static function format_quiz(\stdClass $quiz, \cm_info $cm, \context $context): array {
        global $DB;

        return [
            'id' => (int) $quiz->id,
            'cmid' => (int) $cm->id,
            'courseid' => (int) $quiz->course,
            'name' => format_string($quiz->name, true, ['context' => $context]),
            'intro' => (string) $quiz->intro,
            'introformat' => (int) $quiz->introformat,
            'section' => (int) $cm->sectionnum,
            'visible' => (bool) $cm->visible,
            'timeopen' => (int) $quiz->timeopen,
            'timeclose' => (int) $quiz->timeclose,
            'attempts' => (int) $quiz->attempts,
            'questioncount' => (int) $DB->count_records('quiz_slots', ['quizid' => $quiz->id]),
            'url' => (new \moodle_url('/mod/quiz/view.php', ['id' => $cm->id]))->out(false),
        ];
    }

    /**
     * Formats one quiz slot / question for the web service response.
     *
     * @param \stdClass $slot Quiz slot record.
     * @param \stdClass $question Question record.
     * @param \stdClass $version Question version record.
     * @return array
     */
    private static function format_question(\stdClass $slot, \stdClass $question, \stdClass $version): array {
        global $DB;

        $answers = [];
        $records = $DB->get_records('question_answers', ['question' => $question->id], 'id ASC');
        foreach ($records as $answer) {
            $fraction = (float) $answer->fraction;
            $answers[] = [
                'id' => (int) $answer->id,
                'answer' => (string) $answer->answer,
                'answerformat' => (int) $answer->answerformat,
                'answerplain' => html_to_text((string) $answer->answer, 0, false),
                'fraction' => $fraction,
                'correct' => $fraction > 0,
                'feedback' => (string) $answer->feedback,
                'feedbackformat' => (int) $answer->feedbackformat,
            ];
        }

        return [
            'id' => (int) $question->id,
            'slot' => (int) $slot->slot,
            'page' => (int) $slot->page,
            'maxmark' => (float) $slot->maxmark,
            'versionid' => (int) $version->id,
            'version' => (int) $version->version,
            'status' => property_exists($version, 'status') ? (string) $version->status : '',
            'name' => format_string((string) $question->name),
            'qtype' => (string) $question->qtype,
            'questiontext' => (string) $question->questiontext,
            'questiontextformat' => (int) $question->questiontextformat,
            'questiontextplain' => html_to_text((string) $question->questiontext, 0, false),
            'generalfeedback' => (string) $question->generalfeedback,
            'generalfeedbackformat' => (int) $question->generalfeedbackformat,
            'defaultmark' => (float) $question->defaultmark,
            'penalty' => (float) $question->penalty,
            'supported' => in_array($question->qtype, self::SUPPORTED_TYPES, true),
            'answers' => $answers,
            'options' => self::get_question_options($question),
        ];
    }

    /**
     * Returns qtype specific options (only the fields used to understand the answer key).
     *
     * @param \stdClass $question Question record.
     * @return array
     */
    private static function get_question_options(\stdClass $question): array {
        global $DB;

        try {
            switch ($question->qtype) {
            case 'multichoice':
                $options = $DB->get_record('qtype_multichoice_options',
                    ['question' => $question->id], '*', IGNORE_MISSING);
                if (!$options) {
                    return [];
                }
                return [
                    'single' => (bool) $options->single,
                    'shuffleanswers' => (bool) $options->shuffleanswers,
                    'answernumbering' => (string) $options->answernumbering,
                    'showstandardinstruction' => property_exists($options, 'showstandardinstruction')
                        ? (bool) $options->showstandardinstruction : false,
                ];

            case 'truefalse':
                $options = $DB->get_record('qtype_truefalse_options',
                    ['question' => $question->id], '*', IGNORE_MISSING);
                if (!$options) {
                    return [];
                }
                return [
                    'trueanswer' => (int) $options->trueanswer,
                    'falseanswer' => (int) $options->falseanswer,
                    'showstandardinstruction' => property_exists($options, 'showstandardinstruction')
                        ? (bool) $options->showstandardinstruction : false,
                ];

            case 'match':
                $options = $DB->get_record('qtype_match_options',
                    ['question' => $question->id], '*', IGNORE_MISSING);
                $subquestions = [];
                $subs = $DB->get_records('qtype_match_subquestions',
                    ['questionid' => $question->id], 'id ASC');
                foreach ($subs as $sub) {
                    $subquestions[] = [
                        'id' => (int) $sub->id,
                        'questiontext' => (string) $sub->questiontext,
                        'answertext' => (string) $sub->answertext,
                        'code' => (int) $sub->code,
                    ];
                }
                return [
                    'shuffleanswers' => $options ? (bool) $options->shuffleanswers : false,
                    'showstandardinstruction' => ($options && property_exists($options, 'showstandardinstruction'))
                        ? (bool) $options->showstandardinstruction : false,
                    'subquestions' => $subquestions,
                ];

            default:
                return [];
            }
        } catch (\Throwable $error) {
            // Algunas instalaciones de Moodle 5.x no tienen las tablas de
            // opciones de qtype con la misma estructura. Las opciones no son
            // necesarias para el juego: se devuelven vacías en vez de romper.
            return [];
        }
    }
}
