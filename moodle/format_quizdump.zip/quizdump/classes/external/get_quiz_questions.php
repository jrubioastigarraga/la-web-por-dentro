<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace format_quizdump\external;

defined('MOODLE_INTERNAL') || die();

use format_quizdump\local\quiz_service;

/**
 * Web service: questions, answers and correct answers of a quiz.
 *
 * @package   format_quizdump
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class get_quiz_questions extends \core_external\external_api {

    /**
     * Describes the parameters.
     *
     * @return \core_external\external_function_parameters
     */
    public static function execute_parameters(): \core_external\external_function_parameters {
        return new \core_external\external_function_parameters([
            'quizid' => new \core_external\external_value(PARAM_INT, 'Quiz instance id (not cmid)', VALUE_REQUIRED),
            'includehidden' => new \core_external\external_value(PARAM_BOOL,
                'Include hidden quizzes (needs moodle/course:manageactivities)', VALUE_DEFAULT, false),
        ]);
    }

    /**
     * Returns the quiz with all its questions and answers.
     *
     * @param int $quizid Quiz instance id.
     * @param bool $includehidden Whether to allow hidden quizzes.
     * @return array
     */
    public static function execute(int $quizid, bool $includehidden = false): array {
        global $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'quizid' => $quizid,
            'includehidden' => $includehidden,
        ]);

        return quiz_service::get_quiz_questions(
            (int) $params['quizid'],
            (int) $USER->id,
            (bool) $params['includehidden']
        );
    }

    /**
     * Describes the return value.
     *
     * @return \core_external\external_single_structure
     */
    public static function execute_returns(): \core_external\external_single_structure {
        return new \core_external\external_single_structure([
            'quiz' => new \core_external\external_single_structure([
                'id' => new \core_external\external_value(PARAM_INT, 'Quiz id'),
                'cmid' => new \core_external\external_value(PARAM_INT, 'Course module id'),
                'courseid' => new \core_external\external_value(PARAM_INT, 'Course id'),
                'name' => new \core_external\external_value(PARAM_TEXT, 'Quiz name'),
                'intro' => new \core_external\external_value(PARAM_RAW, 'Quiz intro (HTML)'),
                'introformat' => new \core_external\external_value(PARAM_INT, 'Intro format'),
                'section' => new \core_external\external_value(PARAM_INT, 'Course section number'),
                'visible' => new \core_external\external_value(PARAM_BOOL, 'Whether the activity is visible'),
                'timeopen' => new \core_external\external_value(PARAM_INT, 'Quiz open time'),
                'timeclose' => new \core_external\external_value(PARAM_INT, 'Quiz close time'),
                'attempts' => new \core_external\external_value(PARAM_INT, 'Attempts allowed'),
                'questioncount' => new \core_external\external_value(PARAM_INT, 'Number of question slots'),
                'url' => new \core_external\external_value(PARAM_URL, 'Quiz view URL'),
            ]),
            'questions' => new \core_external\external_multiple_structure(
                new \core_external\external_single_structure([
                    'id' => new \core_external\external_value(PARAM_INT, 'Question id'),
                    'slot' => new \core_external\external_value(PARAM_INT, 'Quiz slot number'),
                    'page' => new \core_external\external_value(PARAM_INT, 'Page number'),
                    'maxmark' => new \core_external\external_value(PARAM_FLOAT, 'Maximum mark for this slot'),
                    'versionid' => new \core_external\external_value(PARAM_INT, 'Question version id'),
                    'version' => new \core_external\external_value(PARAM_INT, 'Question version number'),
                    'status' => new \core_external\external_value(PARAM_TEXT, 'Version status', VALUE_OPTIONAL, ''),
                    'name' => new \core_external\external_value(PARAM_TEXT, 'Question name'),
                    'qtype' => new \core_external\external_value(PARAM_TEXT, 'Question type'),
                    'questiontext' => new \core_external\external_value(PARAM_RAW, 'Question text (HTML)'),
                    'questiontextformat' => new \core_external\external_value(PARAM_INT, 'Question text format'),
                    'questiontextplain' => new \core_external\external_value(PARAM_RAW, 'Question text without HTML'),
                    'generalfeedback' => new \core_external\external_value(PARAM_RAW, 'General feedback (HTML)'),
                    'generalfeedbackformat' => new \core_external\external_value(PARAM_INT, 'General feedback format'),
                    'defaultmark' => new \core_external\external_value(PARAM_FLOAT, 'Default mark'),
                    'penalty' => new \core_external\external_value(PARAM_FLOAT, 'Penalty'),
                    'supported' => new \core_external\external_value(PARAM_BOOL,
                        'Whether the answers could be extracted reliably'),
                    'answers' => new \core_external\external_multiple_structure(
                        new \core_external\external_single_structure([
                            'id' => new \core_external\external_value(PARAM_INT, 'Answer id'),
                            'answer' => new \core_external\external_value(PARAM_RAW, 'Answer text (HTML)'),
                            'answerformat' => new \core_external\external_value(PARAM_INT, 'Answer text format'),
                            'answerplain' => new \core_external\external_value(PARAM_RAW, 'Answer text without HTML'),
                            'fraction' => new \core_external\external_value(PARAM_FLOAT,
                                'Score fraction: > 0 means correct, < 0 means penalty'),
                            'correct' => new \core_external\external_value(PARAM_BOOL, 'Whether this answer is correct'),
                            'feedback' => new \core_external\external_value(PARAM_RAW, 'Answer feedback (HTML)'),
                            'feedbackformat' => new \core_external\external_value(PARAM_INT, 'Answer feedback format'),
                        ])
                    ),
                    'options' => new \core_external\external_single_structure([
                        'single' => new \core_external\external_value(PARAM_BOOL, 'Single choice (multichoice)',
                            VALUE_OPTIONAL),
                        'shuffleanswers' => new \core_external\external_value(PARAM_BOOL, 'Shuffle answers', VALUE_OPTIONAL),
                        'answernumbering' => new \core_external\external_value(PARAM_TEXT, 'Answer numbering',
                            VALUE_OPTIONAL),
                        'showstandardinstruction' => new \core_external\external_value(PARAM_BOOL,
                            'Show standard instruction', VALUE_OPTIONAL),
                        'trueanswer' => new \core_external\external_value(PARAM_INT, 'Answer id for "true" (truefalse)',
                            VALUE_OPTIONAL),
                        'falseanswer' => new \core_external\external_value(PARAM_INT, 'Answer id for "false" (truefalse)',
                            VALUE_OPTIONAL),
                        'subquestions' => new \core_external\external_multiple_structure(
                            new \core_external\external_single_structure([
                                'id' => new \core_external\external_value(PARAM_INT, 'Subquestion id'),
                                'questiontext' => new \core_external\external_value(PARAM_RAW, 'Subquestion text'),
                                'answertext' => new \core_external\external_value(PARAM_RAW, 'Correct matching answer'),
                                'code' => new \core_external\external_value(PARAM_INT, 'Answer code'),
                            ]),
                            'Matching subquestions',
                            VALUE_OPTIONAL
                        ),
                    ], 'Question type specific options', VALUE_OPTIONAL),
                ])
            ),
        ]);
    }
}
