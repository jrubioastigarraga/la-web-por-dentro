<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace format_quizdump\external;

defined('MOODLE_INTERNAL') || die();

use format_quizdump\local\quiz_service;

/**
 * Web service: list the visible quizzes of a course.
 *
 * @package   format_quizdump
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class get_quizzes extends \core_external\external_api {

    /**
     * Describes the parameters.
     *
     * @return \core_external\external_function_parameters
     */
    public static function execute_parameters(): \core_external\external_function_parameters {
        return new \core_external\external_function_parameters([
            'courseid' => new \core_external\external_value(PARAM_INT, 'Course id', VALUE_REQUIRED),
        ]);
    }

    /**
     * Returns the visible quizzes of the course.
     *
     * @param int $courseid Course id.
     * @return array
     */
    public static function execute(int $courseid): array {
        global $USER;

        $params = self::validate_parameters(self::execute_parameters(), ['courseid' => $courseid]);

        $context = \context_course::instance((int) $params['courseid']);
        self::validate_context($context);
        require_capability('format/quizdump:view', $context);

        return [
            'quizzes' => quiz_service::get_visible_quizzes((int) $params['courseid'], (int) $USER->id),
        ];
    }

    /**
     * Describes the return value.
     *
     * @return \core_external\external_single_structure
     */
    public static function execute_returns(): \core_external\external_single_structure {
        return new \core_external\external_single_structure([
            'quizzes' => new \core_external\external_multiple_structure(
                new \core_external\external_single_structure([
                    'id' => new \core_external\external_value(PARAM_INT, 'Quiz id'),
                    'cmid' => new \core_external\external_value(PARAM_INT, 'Course module id'),
                    'courseid' => new \core_external\external_value(PARAM_INT, 'Course id'),
                    'name' => new \core_external\external_value(PARAM_TEXT, 'Quiz name'),
                    'intro' => new \core_external\external_value(PARAM_RAW, 'Quiz intro (HTML)'),
                    'introformat' => new \core_external\external_value(PARAM_INT, 'Intro format'),
                    'section' => new \core_external\external_value(PARAM_INT, 'Course section number'),
                    'visible' => new \core_external\external_value(PARAM_BOOL, 'Whether the activity is visible'),
                    'timeopen' => new \core_external\external_value(PARAM_INT, 'Quiz open time'),
                    'timeclose' => new \core_external\external_value(PARAM_INT, 'Quiz close time'),
                    'attempts' => new \core_external\external_value(PARAM_INT, 'Attempts allowed'),
                    'questioncount' => new \core_external\external_value(PARAM_INT, 'Number of question slots'),
                    'url' => new \core_external\external_value(PARAM_URL, 'Quiz view URL'),
                ])
            ),
        ]);
    }
}
