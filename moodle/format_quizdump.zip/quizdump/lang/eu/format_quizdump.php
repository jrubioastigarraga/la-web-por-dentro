<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Basque strings for format_quizdump.
 *
 * @package   format_quizdump
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['errorquiznotavailable'] = 'Galdetegia ez dago erabilgarri erabiltzaile honentzat (sekzio ezkutua edo erabilgarritasun-murrizketak).';
$string['errorquiznotvisible'] = 'Galdetegia ez dago ikusgai. Gaitu "ezkutukoak sartu" aukera edo egin galdetegia ikusgai.';
$string['pluginname'] = 'Quiz dump (galderak eta erantzunak)';
$string['privacy:metadata'] = 'Quiz dump pluginak ez du datu pertsonalik gordetzen.';
$string['quizdump:view'] = 'Galdetegien galderak, erantzunak eta erantzun zuzenak ikusi web-zerbitzuen bidez';
