<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English strings for format_quizdump.
 *
 * @package   format_quizdump
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['errorquiznotavailable'] = 'The quiz is not available to this user (hidden section or availability restrictions).';
$string['errorquiznotvisible'] = 'The quiz is not visible. Enable the "include hidden" option or make the quiz visible.';
$string['pluginname'] = 'Quiz dump (questions and answers)';
$string['privacy:metadata'] = 'The Quiz dump plugin does not store any personal data.';
$string['quizdump:view'] = 'View quiz questions, answers and correct answers through web services';
